import { Margin, TextFormat } from "@mui/icons-material";
import MKTypography from "components/MKTypography";
const featuresCode = (
  <>
    <h1>
      <b>MEETING SA NEKONAL</b>
    </h1>
  </>
);

export default featuresCode;
