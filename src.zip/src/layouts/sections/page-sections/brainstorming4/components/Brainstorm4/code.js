import { Margin } from "@mui/icons-material";
const brainstorm4Code = (
  <>
    <ul>
      <li>Streak</li>
      <br />
      <li>Buduješ dom, stromček, oblečenie?</li>
      <br />
      <li>Notifikácia - domyslieť kedy posielať push notifikáciu</li>
      <br />
      <li>
        Možnosť za odmenu kúpiť zvuk
        <ul style={{ marginLeft: 30 + "px" }}>
          <li>
            príklad - vytvoríš si postavičku, kupuješ jej oblečenie, okuliare,
            šperky, vlasy, pozadie (lietaš vo vesmíre atď.)
          </li>
        </ul>
      </li>
    </ul>
  </>
);

export default brainstorm4Code;
